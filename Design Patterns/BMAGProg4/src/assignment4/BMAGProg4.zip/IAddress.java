package assignment4;

public interface IAddress {
	void inputAddress();
	
	void printAddress();
	
	void editLastName();
	
	void editFirstName();
	
	void editTitle();
	
	void editFourDigitCode();
	
	void editCity();

	void editStreetName();
	
	void editStreetNumber();
	
	void editApartmentFloor();
	
	void editApartmentNumber();
}
