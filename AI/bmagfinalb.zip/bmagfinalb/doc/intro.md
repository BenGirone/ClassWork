# Introduction to bmagfinalb

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
